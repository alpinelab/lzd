=== BSK Files Manager ===
Contributors: bannersky
Donate link: http://www.bannersky.com/donate
Plugin URI: http://www.bannersky.com/html/bsk-files-manager.html
Tags: files,manager,category,widget
Requires at least: 3.2.1
Tested up to: 3.5.1
Stable tag: 1.0.0

== Description ==

The plugin help you manage your files documents in WordPress. You may upload your files into one category and display all files under the category in front. Or you may show a special file in front.

It is easy to use. You just need copy the short codes into the page/post where you want to show. Then it will show the links of your file.

You may also use files extension name as filter to show files in front.

== Installation ==

Activate the plugin then you can use either a short code [bsk-files-manager-files id=xx] to show a special file.

Or [bsk-files-category id=xx] to show all fiels under a category.

Or [bsk-files-category id=xx extension="zip"] to show all fiels under category of id xx and with an extension of zip .

The plugin has a very easy admin page that allows you to manage categories and files.



== Frequently Asked Questions ==

Please visit <a href="http://www.bannersky.com/html/bsk-files-manager.html">http://www.bannersky.com/html/bsk-files-manager.html</a> for support.

== Screenshots ==

1. Admin interface of categories manager
2. Admin interface of files
3. Admin interface of add files


== Changelog ==

1.0.0 First version.

