=== WP Footer Menu ===

Plugin Name: WP Footer Menu
Plugin URI: http://www.graemeboy.com
Description: Adds a footer menu to your blog, customizable in wp-admin.
Version: 2.0
Author: Graeme Boy
Author URI: http://www.graemeboy.com
License: GPL2

== Description ==

WP Footer Menu is a very simple plugin that adds a settings page to wp-admin, which allows you to customize a footer menu.

== Installation ==

1. Upload the WP Footer Menu directory to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Use the options page under "Settings" to make changes.

== Frequently Asked Questions ==

= How do I contact you? =

Email graemeboy@gmail.com

= Is this plugin free? =

Yes.

== Changelog ==

= 2.0 =
Added some more customization features.

= 1.0 =
The initial version of this plugin.